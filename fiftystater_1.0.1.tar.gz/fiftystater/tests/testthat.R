library(testthat)
library(fiftystater)

test_check("fiftystater")
