#### Version 1.0.1

* `fifty_states` data object to easily make 50-state choropleth thematic maps in ggplot2 by including Alaska and Hawaii as insets
* `fifty_states_inset_boxes` function to add border boxes to the insets, 
if desired
